var structampelparameter =
[
    [ "event", "structampelparameter.html#ad70553c5639d1dbd1db238ba0ede8fc2", null ],
    [ "modus", "structampelparameter.html#ac2f9c5a8ed7b3978c304740db3db8bc4", null ],
    [ "zustand", "structampelparameter.html#aa3e849a47e5e680b0f4fe0d2d4727126", null ]
];