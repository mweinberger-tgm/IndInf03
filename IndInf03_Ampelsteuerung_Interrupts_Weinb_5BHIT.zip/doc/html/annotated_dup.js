var annotated_dup =
[
    [ "ampelparameter", "structampelparameter.html", "structampelparameter" ]
];