var control_8h =
[
    [ "led_gelb", "control_8h.html#a7fb6863a7b9298e755f0cdb9344dceff", null ],
    [ "led_gruen", "control_8h.html#a0a8db47d447cbe24ac18867af7485301", null ],
    [ "led_gruen_blinken", "control_8h.html#abac6e28c52d1b1fbf9f3039d0e5fda6d", null ],
    [ "led_init", "control_8h.html#a7b3b624857fba1776c75412289a20230", null ],
    [ "led_off", "control_8h.html#a501391b8794d0beaeaf0dea7a3bdbbb3", null ],
    [ "led_rot", "control_8h.html#acf33f923d311e918f6ff58d5e36f2820", null ],
    [ "led_rot_gelb", "control_8h.html#aef77f7543d6efae25faca22475404395", null ]
];